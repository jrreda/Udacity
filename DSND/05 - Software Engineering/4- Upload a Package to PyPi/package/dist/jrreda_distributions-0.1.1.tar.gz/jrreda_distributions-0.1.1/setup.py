# TODO: Fill out this file with information about your package

from setuptools import setup

setup(name='jrreda_distributions',
      version='0.1.1',
      description='Gaussian & Binomial distributions',
      packages=['jrreda_distributions'],
      auther='Mahmoud Reda',
      auther_email='mahmoudreda457@gmail.com',
      license='MIT',
      zip_safe=False)
